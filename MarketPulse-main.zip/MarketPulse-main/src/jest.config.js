module.exports = {
    setupFilesAfterEnv: ["<rootDir>/setupTests.js"],
    moduleDirectories: ['node_modules', 'src'],
  };