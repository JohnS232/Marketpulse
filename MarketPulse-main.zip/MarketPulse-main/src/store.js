import { userUpdateReducer } from "./resources/Profile";

const reducer = combineReducers({
    userUpdate: userUpdateReducer
})