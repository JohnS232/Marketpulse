export const twelvedata = {
    api_token: '6a42127caef7439bb6acd56f27e57319',
    base_url: 'https://api.twelvedata.com'
};