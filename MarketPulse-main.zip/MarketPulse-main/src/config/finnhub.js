export const finnhub = {
    api_token: 'cvluuj1r01qnndmb1rhgcvluuj1r01qnndmb1ri0',
    base_url: 'https://finnhub.io/api/v1'
};